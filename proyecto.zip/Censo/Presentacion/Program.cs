﻿using System.Text;
using System.Threading.Tasks;

namespace Presentacion
{
    internal class program
    {
        static void Main(string[] args)
        {
            MenuPrincipal vermenu = new MenuPrincipal();
            vermenu.VerMenuPrincipal();
        }
    }
}